from flask import Flask
app = Flask(__name__)
app.secret_key = "Fun Fact:Im closer to being a millionaire than Jeff Bezos"