from flask import Flask, render_template, redirect, request,session, flash
from flask_app.models.user import User
from flask_app.models.recipe import Recipe
from flask_app import app

@app.route('/add_recipe')
def add_recipe():
    return render_template("add.html")

@app.route('/create_recipe', methods = ['POST'])
def create_recipe():
    data = {
        "name": request.form['name'],
        "description": request.form['description'],
        "instructions": request.form['instructions'],
        "date_cooked": request.form['date_cooked'],
        "user_id": session['user_id']
    }
    Recipe.create(data)
    return redirect('/recipes')

@app.route('/recipe/<int:id>')
def one_recipe(id):
    data = {
        "id": id
    }
    a_recipe = Recipe.get_one(data)
    return render_template("info.html", one_recipe = a_recipe)

@app.route('/delete/<int:id>', methods=['POST'])
def delete(id):
    data = {
        "id": id
    }
    Recipe.demolish(data)
    return redirect('/recipes')

@app.route('/edit/<int:id>')
def edit_recipe(id):
    data = {
        "id": id
    }
    a_recipe = Recipe.get_one(data)
    return render_template('edit.html', one_recipe = a_recipe)
