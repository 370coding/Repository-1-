from flask_app.config.mysqlconnection import connectToMySQL
from flask_app.models import user
from flask import flash


class Recipe:
    def __init__(self,data):
        self.id = data['id']
        self.name = data['name']
        self.description = data['description']
        self.instructions = data['instructions']
        self.date_cooked = data['date_cooked']
        self.created_at = data['created_at']
        self.updated_at = data['updated_at']
        self.creator = None

    @classmethod
    def create(cls,data):
        query = "INSERT INTO recipes (name, description, instructions,date_cooked, user_id) VALUES (%(name)s,%(description)s,%(instructions)s, %(date_cooked)s,%(user_id)s);"
        results = connectToMySQL('recipe_schema').query_db(query, data)
        print(results)
        return results

    @classmethod
    def get_all_with_creator(cls,data):
        query = "SELECT* FROM recipes JOIN users ON users.id = recipes.user_id;"
        results = connectToMySQL('recipe_schema').query_db(query, data)
        print(results)
        all_recipes = []

        for row in results:
            one_recipe = cls(row)
            user_data = {
                "id": row['user_id'],
                "first_name": row["first_name"],
                "last_name": row['last_name'],
                "email": row['email'],
                "password": None,
                "created_at": row['created_at'],
                "updated_at": row['updated_at']
            }
            user_obj = user.User(user_data)
            one_recipe.creator = user_obj
            all_recipes.append(one_recipe)
        return all_recipes

    @classmethod
    def get_one(cls,data):
        query = "SELECT * FROM recipes WHERE id = %(id)s;"
        results = connectToMySQL('recipe_schema').query_db(query,data)
        print(results)
        return cls(results[0])

    @classmethod
    def demolish(cls,data):
        query = "DELETE FROM recipes WHERE id = %(id)s;"
        results = connectToMySQL('recipe_schema').query_db(query,data)
        print(results)
        return results